// ─── Supervisor (substitui o PM2 na versão instalável) ────────────────────────
// Inicia api.js e bot.js, reinicia se caírem, e controla o robô por arquivo-flag.
// Roda com o Node portátil embutido. Sem janela, sem dependências externas.
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const DIR = __dirname;
const NODE = process.execPath;                       // o node portátil que rodou este script
const BOT_FLAG     = path.join(DIR, "bot.enabled");  // existe = robô ligado
const RESTART_FLAG = path.join(DIR, "restart.flag"); // existe = reiniciar tudo (usado no update)

// Aponta o Playwright pro navegador embutido (pasta ../browser).
// Se a pasta não existir (instalação master/dev), deixa o Playwright usar o cache padrão.
const BROWSER_DIR = path.join(DIR, "..", "browser");
const ENV = {
  ...process.env,
  ...(fs.existsSync(BROWSER_DIR) ? { PLAYWRIGHT_BROWSERS_PATH: BROWSER_DIR } : {}),
  BOT_STARTUP_DELAY: "15000",
};

let api = null, bot = null, encerrando = false;

function startApi() {
  if (api || encerrando) return;
  api = spawn(NODE, [path.join(DIR, "api.js")], { cwd: DIR, stdio: "ignore", windowsHide: true, env: ENV });
  api.on("exit", () => { api = null; if (!encerrando) setTimeout(startApi, 3000); });
}
function startBot() {
  if (bot) return;
  bot = spawn(NODE, [path.join(DIR, "bot.js")], { cwd: DIR, stdio: "ignore", windowsHide: true, env: ENV });
  bot.on("exit", () => { bot = null; });
}
function stopBot() { if (bot) { try { bot.kill(); } catch {} bot = null; } }

startApi();
if (fs.existsSync(BOT_FLAG)) startBot();

setInterval(() => {
  if (encerrando) return;
  // Liga/desliga o robô conforme o flag
  const querBot = fs.existsSync(BOT_FLAG);
  if (querBot && !bot) startBot();
  if (!querBot && bot) stopBot();

  // Reinício geral (disparado pelo update)
  if (fs.existsSync(RESTART_FLAG)) {
    try { fs.unlinkSync(RESTART_FLAG); } catch {}
    if (api) { try { api.kill(); } catch {} api = null; }
    stopBot();
    setTimeout(() => { startApi(); if (fs.existsSync(BOT_FLAG)) startBot(); }, 1500);
  }
}, 3000);

function fim() { encerrando = true; if (api) try { api.kill(); } catch {} stopBot(); process.exit(0); }
process.on("SIGTERM", fim);
process.on("SIGINT", fim);
