// ─── Supervisor (substitui o PM2 na versão instalável) ────────────────────────
// Inicia api.js e bot.js, reinicia se caírem, e controla o robô por arquivo-flag.
// Roda com o Node portátil embutido. Sem janela, sem dependências externas.
const { spawn } = require("child_process");
const fs = require("fs");
const path = require("path");

const DIR = __dirname;
const NODE = process.execPath;                       // o node portátil que rodou este script
const BOT_FLAG     = path.join(DIR, "bot.enabled");  // existe = robô ligado
const RESTART_FLAG = path.join(DIR, "restart.flag"); // existe = reiniciar tudo (usado no update)
const HEARTBEAT    = path.join(DIR, "bot_heartbeat.json"); // bot.js escreve {ts} a cada 30s
const HB_LIMITE_MS = 4 * 60 * 1000;                  // heartbeat parado +4min = bot travado → reinicia

// ─── Log em arquivo (observabilidade) ─────────────────────────────────────────
// Antes o stdout/stderr do api e do bot eram descartados (stdio:"ignore"), então
// nas instalações de cliente não sobrava NENHUM log pra diagnosticar problema.
// Agora grava em promobot.log, com teto: no boot, se passou de 5MB, roda pra .old.
const LOG_PATH = path.join(DIR, "promobot.log");
const LOG_MAX  = 5 * 1024 * 1024;
let logFd = null;
function abrirLog() {
  try {
    if (fs.existsSync(LOG_PATH) && fs.statSync(LOG_PATH).size > LOG_MAX) {
      try { fs.rmSync(LOG_PATH + ".old", { force: true }); } catch {}
      try { fs.renameSync(LOG_PATH, LOG_PATH + ".old"); } catch {}
    }
    logFd = fs.openSync(LOG_PATH, "a");
    fs.writeSync(logFd, `\n===== supervisor iniciado ${new Date().toISOString()} =====\n`);
  } catch { logFd = null; } // se não der pra abrir, cai no comportamento antigo (silencioso)
}
abrirLog();
const SAIDA = () => (logFd != null ? logFd : "ignore");

// Aponta o Playwright pro navegador embutido (pasta ../browser).
// Se a pasta não existir (instalação master/dev), deixa o Playwright usar o cache padrão.
const BROWSER_DIR = path.join(DIR, "..", "browser");
const ENV = {
  ...process.env,
  ...(fs.existsSync(BROWSER_DIR) ? { PLAYWRIGHT_BROWSERS_PATH: BROWSER_DIR } : {}),
  BOT_STARTUP_DELAY: "15000",
};

let api = null, bot = null, encerrando = false;

function startApi() {
  if (api || encerrando) return;
  api = spawn(NODE, [path.join(DIR, "api.js")], { cwd: DIR, stdio: ["ignore", SAIDA(), SAIDA()], windowsHide: true, env: ENV });
  api.on("exit", () => { api = null; if (!encerrando) setTimeout(startApi, 3000); });
}
let botIniciadoEm = 0;
function startBot() {
  if (bot) return;
  botIniciadoEm = Date.now();
  bot = spawn(NODE, [path.join(DIR, "bot.js")], { cwd: DIR, stdio: ["ignore", SAIDA(), SAIDA()], windowsHide: true, env: ENV });
  bot.on("exit", () => { bot = null; });
}
// ─── Impedir que o Windows suspenda a maquina ────────────────────────────────
// A manutencao automatica do Windows manda o PC dormir de madrugada ("Motivo da
// Suspensao: Application API"), mesmo com a suspensao por inatividade desligada.
// O bot parava por horas: numa madrugada foram 10h suspenso, e a rodada das 9h
// do painel de afiliados simplesmente nao aconteceu.
//
// A solucao e a mesma que um player de video usa: avisar ao Windows que ha
// trabalho em andamento (SetThreadExecutionState com ES_SYSTEM_REQUIRED +
// ES_CONTINUOUS). Vale enquanto este processo viver; ao encerrar, o Windows
// volta ao comportamento normal sozinho. NAO mexe nas configuracoes de energia
// da maquina do cliente.
let guardaSono = null;
function manterPcAcordado() {
  if (process.platform !== "win32") return;
  try {
    const cfg = JSON.parse(fs.readFileSync(path.join(DIR, "config.json"), "utf-8"));
    if (cfg.manterPcAcordado === false) { log("PC pode suspender (desligado no painel)."); return; }
  } catch {}
  const ps = [
    "Add-Type -Name P -Namespace W -MemberDefinition '[DllImport(\"kernel32.dll\")] public static extern uint SetThreadExecutionState(uint e);';",
    // 0x80000001 = ES_CONTINUOUS | ES_SYSTEM_REQUIRED. Precisa ir como UInt32:
    // escrito como 0x... o PowerShell le como Int32 negativo e a chamada falha.
    "[W.P]::SetThreadExecutionState([Convert]::ToUInt32(\"80000001\",16)) | Out-Null;",
    "while ($true) { Start-Sleep -Seconds 60 }",
  ].join(" ");
  try {
    guardaSono = spawn("powershell", ["-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", ps],
      { stdio: "ignore", windowsHide: true, detached: false });
    guardaSono.on("exit", () => { guardaSono = null; });
    log("Mantendo o PC acordado enquanto o robo estiver ligado.");
  } catch (e) {
    log("Nao consegui impedir a suspensao: " + (e.message || e));
  }
}
function liberarSono() { if (guardaSono) { try { guardaSono.kill(); } catch {} guardaSono = null; } }

function stopBot() { if (bot) { try { bot.kill(); } catch {} bot = null; } }

// Watchdog: bot.js escreve o heartbeat a cada 30s mesmo durante scraping (timer próprio).
// Se ele congelar por +4min com o robô ligado, o processo travou (WhatsApp preso,
// página pendurada, etc.) — mata e deixa o supervisor subir de novo no próximo tick.
function heartbeatTravado() {
  // dá 90s de graça após iniciar (o primeiro heartbeat tem delay)
  if (!bot || (Date.now() - botIniciadoEm) < 90000) return false;
  try {
    const hb = JSON.parse(fs.readFileSync(HEARTBEAT, "utf-8"));
    return (Date.now() - hb.ts) > HB_LIMITE_MS;
  } catch { return false; }  // sem arquivo ainda = não age
}

manterPcAcordado();
startApi();
if (fs.existsSync(BOT_FLAG)) startBot();

setInterval(() => {
  if (encerrando) return;
  // Liga/desliga o robô conforme o flag
  const querBot = fs.existsSync(BOT_FLAG);
  if (querBot && !bot) startBot();
  if (!querBot && bot) stopBot();

  // Watchdog: bot ligado mas heartbeat congelado → travou, reinicia
  if (querBot && heartbeatTravado()) {
    stopBot();           // mata o travado; o próximo tick (3s) sobe de novo
  }

  // Reinício geral (disparado pelo update)
  if (fs.existsSync(RESTART_FLAG)) {
    try { fs.unlinkSync(RESTART_FLAG); } catch {}
    if (api) { try { api.kill(); } catch {} api = null; }
    stopBot();
    setTimeout(() => { startApi(); if (fs.existsSync(BOT_FLAG)) startBot(); }, 1500);
  }
}, 3000);

function fim() { encerrando = true; liberarSono(); if (api) try { api.kill(); } catch {} stopBot(); process.exit(0); }
process.on("SIGTERM", fim);
process.on("SIGINT", fim);
